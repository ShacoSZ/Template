export class libroIdioma{
    id?:number;
    libro_id?:number;
    idioma_id?:number;
    nombre?:string;
    idioma?:string;
}