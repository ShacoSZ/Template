export class Idioma{
    id?: number;
    idioma?: string;
}