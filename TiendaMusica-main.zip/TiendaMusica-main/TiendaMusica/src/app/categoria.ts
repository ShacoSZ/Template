export class categoria{
    id?:number;
    categoria?:string;
}