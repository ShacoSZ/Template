export class roles{
    id?:number;
    rol?:string;
}