export class user{
    Token?:string;
    UserID?:number;
    rol_id?:number;
    status?:number;
    name?:string;
}