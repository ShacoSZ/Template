export interface Idioma {
    id: number;
    idioma: string;
}