export interface Usuarios {
    id: number;
    name: string;
    email: string;
    phone: number;
    rol_id:string;
    status:number;
}
