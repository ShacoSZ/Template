export interface Entrar {
    email: string;
    password: string;
}