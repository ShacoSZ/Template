export interface Editoriales {
    id:number;
    nombre:string;
    correo:string;
    direccion:string;
    telefono:number;
}
