export interface Categoria {
    id:number;
    categoria:string;
}
