export interface libroIdioma{
    id:number;
    libro_id:number;
    idioma_id:number;
}