export interface MobileCode {
    Code:Number;
}