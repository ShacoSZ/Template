export interface Salir {
    Bearer:string;
}