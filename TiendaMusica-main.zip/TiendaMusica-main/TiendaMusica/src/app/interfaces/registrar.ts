export interface Registrar {
    name: string;
    email: string;
    phone:number;
    password: string;

}