export interface Autor {
    id: number;
    nombre: string;
}