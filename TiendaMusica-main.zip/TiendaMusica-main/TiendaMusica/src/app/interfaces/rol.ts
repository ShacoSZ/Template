export interface roles{
    id:number;
    rol:string;
}