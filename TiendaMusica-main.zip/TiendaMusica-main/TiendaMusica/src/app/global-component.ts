export class URL {
 
    public static appUrl: string = "http://127.0.0.1:8000/api/";
    // public var prove:string?=null;
 
}