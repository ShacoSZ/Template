import { Injectable } from '@angular/core';
import { ModalesComponent as ModalComponent } from '../components/modales/modales.component';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  private modals: ModalComponent[] = [];

  
}
