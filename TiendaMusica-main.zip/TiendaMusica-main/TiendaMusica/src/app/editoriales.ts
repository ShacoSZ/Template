export class editorial{
    id?:number;
    nombre?:string;
    correo?:string;
    direccion?:string;
    telefono?:number;
}